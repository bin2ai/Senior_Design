# licence
copyright 2013 by michael cousins

this work is made available under the terms of the creative commons attribution-sharealike 3.0 unported license

## creative commons by-sa 3.0
* human readable: http://creativecommons.org/licenses/by-sa/3.0/deed.en_US
* lawyer readable: http://creativecommons.org/licenses/by-sa/3.0/legalcode
